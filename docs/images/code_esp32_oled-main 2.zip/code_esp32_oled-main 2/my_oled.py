from machine import Pin, SoftI2C
import ssd1306
import gfx

# I2C config
i2c = SoftI2C(scl=Pin(4), sda=Pin(5))

# OLED dimensions
oled_width = 128
oled_height = 64
oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c)

# Graphics wrapper
graphics = gfx.GFX(oled_width, oled_height, oled.pixel)

def print_text(msg, x=0, y=0):
    oled.fill(0)
    oled.text(msg, x, y)
    oled.show()

def clear():
    oled.fill(0)
    oled.show()

def draw_line(x1, y1, x2, y2):
    graphics.line(x1, y1, x2, y2)
    oled.show()

def draw_filled_rect(x, y, w, h):
    graphics.fill_rect(x, y, w, h, 1)
    oled.show()
