from machine import UART, Pin
import time
import my_oled

# UART config: TX=43, RX=44 (UART2)
uart = UART(1, baudrate=9600, tx=43, rx=44)

# LED on IO23
led = Pin(23, Pin.OUT)

# Constants
START_BYTE = 0x41
SENDER_ID = 0x03  # HMI ID
END_BYTE = 0x42

# Initial OLED message
my_oled.print_text("Waiting...", 0, 0)

def flash_led(duration=0.1):
    led.on()
    time.sleep(duration)
    led.off()

def forward_message(msg):
    time.sleep(1)  # ~1s delay to give MQTT board time to recover
    uart.write(msg)
    print("Forwarded:", [hex(b) for b in msg])
    flash_led()

def read_message():
    """
    Read a 5-byte UART message if available and valid.
    """
    if uart.any() >= 5:
        msg = uart.read(5)
        if msg and msg[0] == START_BYTE and msg[-1] == END_BYTE:
            print("Received:", [hex(b) for b in msg])
            flash_led()
            return msg
        else:
            print("Invalid message.")
    return None

while True:
    # Listen and forward messages
    incoming = read_message()
    if incoming:
        sender = incoming[1]
        data = incoming[3]
        my_oled.print_text(f"From {hex(sender)}: {hex(data)}", 0, 0)
        forward_message(incoming)

    time.sleep(0.1)
